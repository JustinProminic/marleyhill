---
layout: photo_set
title: Berlin
permalink: /berlin/
description: "An example photo gallery."

photos:
    set: berlin
    size: 3
---